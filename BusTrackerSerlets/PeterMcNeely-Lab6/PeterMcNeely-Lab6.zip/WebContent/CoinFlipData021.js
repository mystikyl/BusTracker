﻿/**
 * The results to be displayed
 * @type {[*]}
 */
var results =
[
	{name:"isenseeca", time:"168", ip:"155.92.69.227", sessionid:"31F873896E3D61B95FFDFCB6C5F7E5F1"},
	{name:"Jacob Walesa", time:"900", ip:"155.92.64.111", sessionid:"7950FF661DEC9885B58DDAECE94FEE88"},
	{name:"Josh McComack", time:"1532", ip:"155.92.65.176", sessionid:"80EC7FC0C326A3CE4DB78ECE7234CD79"},
	{name:"Aavery Grant", time:"709", ip:"155.92.66.168", sessionid:"5ED94D99DAD10E2F20BC8ACEE532A395"},
	{name:"Peter McNeely", time:"600", ip:"155.92.70.60", sessionid:"09BB55DE05FB9CE4261BAEBC5416EC63"},
	{name:"Matthew Schladweiler", time:"1902", ip:"155.92.65.254", sessionid:"B2C16A43F543776F10C942AE4125F8FD"},
	{name:"Connor Hibbs", time:"1202", ip:"155.92.69.73", sessionid:"8F008837D3981C7CAFEF0EF9429D16DF"},
	{name:"Ben Mahon", time:"1232", ip:"155.92.68.51", sessionid:"8EC5183220CBDE00F12F26C648BF0542"},
	{name:"David Yang", time:"842", ip:"155.92.71.231", sessionid:"FADBC81F729D7C592E0A11F101D2F2AA"},
	{name:"Justin", time:"204", ip:"155.92.76.80", sessionid:"18AEC555542DA20267E4AF4B5BB34980"},
	{name:"Karel Gavenciak", time:"2665", ip:"155.92.68.87", sessionid:"F88C0FBEDFD4D752EB9A8631946F2858"},
	{name:"Jenna Sgarlata", time:"843", ip:"155.92.68.229", sessionid:"9E633EBBE12D38AA498B4D7B286C7869"},
	{name:"wallaceja", time:"890", ip:"155.92.67.98", sessionid:"6DA144FFFCB7AFF2785BEA0CC105CE38"},
	{name:"Aureo Ponce", time:"2409", ip:"155.92.70.59", sessionid:"F0E314B03D8C06411B97754DA6EBC473"},
	{name:"Kyra Oberholtzer", time:"141", ip:"155.92.66.171", sessionid:"84A0DDC614B8399D3ADE1E959F45C36F"},
	{name:"Connor Walters", time:"365", ip:"155.92.79.119", sessionid:"E56427ED28B9CFDB76063047F7A7D9FC"},
	{name:"Yahui Liang", time:"500", ip:"155.92.66.34", sessionid:"E17523A42F3C98847C2B58B1DE4631CA"},
	{name:"Geoff Appelbaum", time:"1200", ip:"155.92.65.14", sessionid:"2CB17ABC4DDE315F3CC996374EDB311B"},
	{name:"Nathan Goihl", time:"1100", ip:"155.92.69.110", sessionid:"AE053B55A8BFC326E9DE657C9F2D5424"},
	{name:"Brad Wasilewski", time:"640", ip:"155.92.74.35", sessionid:"A35417B821ABBF340CE6C63C2D308C51"},
	{name:"Andrew S-B", time:"760", ip:"155.92.65.183", sessionid:"443C71FDEDD49A0550940DB075020458"},
	{name:"Nick Dixon", time:"2273", ip:"155.92.69.1", sessionid:"9682E56ACDF068B8FB461065D8D7FEB1"},
	{name:"Luke Fliss", time:"1500", ip:"155.92.69.136", sessionid:"219923954F230BE1C3BD7E041492C45A"},
	{name:"Brandon Jackson", time:"1794", ip:"155.92.76.219", sessionid:"B86F133A1454821ABC7604D7B241A265"},
	{name:"Ryan Guinn", time:"184", ip:"155.92.68.75", sessionid:"A090D313A74F8574FFCA8A133CD99577"},
	{name:"braithwaitec", time:"854", ip:"155.92.69.114", sessionid:"331165334B4C6BD80EAF758EE6A90F33"},
	{name:"Jamie Doro", time:"4820", ip:"155.92.70.194", sessionid:"74FE08F2C6BE1B44C6FE1B811CE83420"},
	{name:"Sheng Ning Jiang", time:"635", ip:"155.92.73.123", sessionid:"647F502C467E20EA370C737EDDE200C0"},
	{name:"Digvijay Yadav", time:"842", ip:"155.92.69.114", sessionid:"331165334B4C6BD80EAF758EE6A90F33"}
];

