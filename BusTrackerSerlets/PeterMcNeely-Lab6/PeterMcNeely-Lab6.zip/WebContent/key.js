/**
 * Created by hornick on 4/12/2016.
 * This file contains your http://realtime.ridemcts.com developer's key
 */
var key = "WLkaSgDPkynqG9TNjVQMi7s7V";
